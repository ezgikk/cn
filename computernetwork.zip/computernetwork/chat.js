// Firebase Initialization
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-app.js"; //Firebase uygulamasını başlatır. Uygulama kimlik bilgilerini içeren nesneyi alır ve firebase hizmerlerini kullanıma hazır hale getirir.
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-auth.js"; //Firebase kimlik doğrulama işlemleri, kullanıcı oturum durumu, kullanıcı oturumu kapatmak için
import { getFirestore, addDoc, collection, query, orderBy, onSnapshot, where, getDocs, updateDoc } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-firestore.js"; //Veritabanı başlatır, yeni belge eklemek için, koleksiyona ulaşmak için, belirli kriterlere göre sorgular oluşturur, sorgu sonuçlarını belirli alana göre sıralama, veritabanındaki değişiklikleri gerçek zamanlı dinler, belirli alanın değerine göre filtreleme yapar, Sorgu sonucundaki belgeleri bir kerede almak için, mevcut bir belgenin içeriğini güncellemek için.

const firebaseConfig = {
    apiKey: "AIzaSyDCAkVAn2GYk9JwTe33G9-IbRl2LzwGVjE", //Projeyle iletişim kurmak için anahtar
    authDomain: "bartin2-7ad48.firebaseapp.com", //Firebase Authentication kullanırken kimlik doğrulama için
    projectId: "bartin2-7ad48", //Proje kimliği
    storageBucket: "bartin2-7ad48.appspot.com", //Dosyaları depolamak için
    messagingSenderId: "1088843251815", //Firebase Cloud Messaging ilgili gönderim kimliğidir.
    appId: "1:1088843251815:web:baeec13841948a248714c2" //Firebase uygulaması eşsiz kimliği
};

const app = initializeApp(firebaseConfig); //Firebase yapılandırma bilgilerini kullanarak uygulamayı başlatır.
const auth = getAuth(); //Firebase Kimlik doğrulama
const db = getFirestore(); //Firestore veritabanını başlatır.
let currentChatFriend = null; //Kullanıcıların şu anda kiminle sohbet ettiğini tutmak için değişken.
let afkTimeout; //Kullanıcının aktif olmadığını algılamak için zamanlayıcıyı temsil eder.
const AFK_LIMIT = 15 * 60 * 1000; // 15 dakika

// DOM Ready
document.addEventListener('DOMContentLoaded', () => {  //Tarayıcıdaki DOM ağacı tamamen yüklendiğinde ve sayfa hazır olduğunda belirtilen işlemleri başlatır.
    setupEventListeners(); //Sayfa üzerindeki kullanıcı etkileşimlerini dinlemek ve uygun işlevleri tetiklemekiçin.
    setupAfkHandler(); // AFK kontrolünü başlat. Kullanıcının aktif olup olmadığını kontrol eden bir zamanlayıcıyı başlatır.

    onAuthStateChanged(auth, (user) => { //Kullanıcı kimlik doğrulama durumu değiştiğinde çağrılır. 
        if (user) {
            loadFriendsList(user.email); //Kullanıcı oturum açmışsa arkadaşl istesi yüklenir. Oturum açmamışsa anasayfaya geri döner.
        } else {
            window.location.href = "index.html";
        }
    });
});

// Event Listeners
function setupEventListeners() { //Arayüzdeki tıklama, fare hareketi  gibi olayları dimlemek için olay dinleyici
    document.getElementById('personalChatButton').addEventListener('click', () => { // Kişisel mesajlar butonuna tıkladığında başlık metni kişisel mesajlar olur ve arakdaş ekleme bölümü etkinleştirilir.
        document.getElementById('chatHeader').textContent = 'Kişisel Mesajlar';
        toggleAddFriendSection(true);
    });

    document.getElementById('groupMessageButton').addEventListener('click', openGroupMessageModal); //Grup mesaj modal penceresini açar. Kapatır ve seçilen alıcılara grup mesajı gönderir.
    document.getElementById('closeModal').addEventListener('click', closeGroupMessageModal);
    document.getElementById('sendGroupMessage').addEventListener('click', sendGroupMessage);

    document.getElementById("logout").addEventListener("click", () => { //Kullanıcı çıkış yap butonuna tıkladığında firebase oturumu kapatılır.
        signOut(auth).then(() => window.location.href = "index.html").catch(console.error);
    });

    document.getElementById("sendMessageButton").addEventListener("click", sendMessage); //Kullanıcı mesaj gönderme butonuna tıkladığında sendmessage işlevi çağrılarak mesaj gönderme işlemi başlatılır.
    document.getElementById('addFriendButton').addEventListener('click', addFriend); //Kullanıcı arkadaş ekleme butonuna tıkladığımda addfriend işlevi çalıştırılır.

    // Sayfa genelindeki etkileşimleri dinle
    document.addEventListener('mousemove', resetAfkTimer);
    document.addEventListener('keydown', resetAfkTimer);
    document.addEventListener('click', resetAfkTimer);
}

// AFK Kontrol
function setupAfkHandler() { //AFK kontrolünü başlatır ve zamanlayıcıyı sıfırlar.
    resetAfkTimer();
}

function resetAfkTimer() { // Kullanıcının afk olup olmadığını kontrol eder
    if (afkTimeout) clearTimeout(afkTimeout); // Daha önce tanımlanmış bir zamanlayıcı varsa bu zamanlayıcıyı iptal eder. 
    afkTimeout = setTimeout(() => {
        signOut(auth).then(() => {
            alert("15 dakika boyunca işlem yapılmadı, oturum kapatıldı.");  //Kullanıcı 15 dk boyunca aktif değilse oturum otomatik kapatılır ve giriş ekranına yönlendirilir.
            window.location.href = "index.html";
        }).catch(console.error);
    }, AFK_LIMIT);
}

// Load Friends List
function loadFriendsList() { //Arkadaş listesini yükleme ve kullanıcı arayüzünde görüntülemek için. 
    const friendItems = document.getElementById("friendItems"); //önceki öğelerin kaldırmasını sağlar. 
    friendItems.innerHTML = "";

    const loggedInUser = auth.currentUser; //Giriş yapmış kullanıcı bilgisi alır.eğer kullaıcı giriş yapmamızsa durur.
    if (!loggedInUser) return;

    const q = query(collection(db, "friends"), orderBy("friend", "asc")); //firestoreda friends koleksiyonu friend alanına göre verileri alfabetik sıraya sıralar.
    onSnapshot(q, (querySnapshot) => { //onsnapshot ve friends koleksiyonunda bir değişiklik olduğunda ekleme silme güncelleme vb otomatik olarak bu değişiklikleri dinler ve listeyi günceller.
        friendItems.innerHTML = "";
        querySnapshot.forEach((doc) => { //sorgudan dönen her bir belgeyi işler.
            const data = doc.data(); //her belgenin verilerini alır.
            if (data.user === loggedInUser.email) { //sadece şuanki kullanıcının eposta adresine ait olan arkadaşlar listelenir.
                const li = document.createElement("li"); //li öğesi oluşur arkadaş adı içine eklenir.
                li.innerHTML = `<span>${data.friend}</span>`; 
                li.addEventListener("click", () => loadChatWith(data.friend)); //bir arkadaş öğesine tıklandığında loadchatwith fonk çağrılarak o arkadaşla sohbet başlatılır.
                friendItems.appendChild(li); //oluşturulan li öğesi arkadaş listesinin DOM'a eklenir.
            }
        });
    });
}

// Add Friend
async function addFriend() { //Htmlde friend emailinput Idsine sahip giriş elemanını seçer. Bu eleman kullanıcıdan bir arkadaşın eposta adresini almayı hedeflerç
    const friendEmailInput = document.getElementById('friendEmailInput');
    const friendEmail = friendEmailInput.value.trim();//Kullanıcının girdiği e-posta adresini alır ve etrafındaki boşlukları (trim()) temizler.

    if (!friendEmail) {
        alert("Lütfen geçerli bir email adresi girin."); //Eğer kullanıcı herhangi bir e-posta adresi girmemişse, bir uyarı mesajı görüntülenir ve fonksiyon işlemi durdurur (return).
        return;
    }

    try {
        const loggedInUser = auth.currentUser; //Firebase Authentication ile oturum açmış kullanıcıyı kontrol eder. Eğer kullanıcı oturum açmamışsa, loggedInUser null olur.
        if (!loggedInUser) return;

        await addDoc(collection(db, "friends"), { //Firebase Firestore veritabanına yeni bir belge ekler. Bu belge, arkadaşlar listesini tutan friends koleksiyonuna, user (giriş yapan kullanıcının e-posta adresi) ve friend (eklenmek istenen arkadaşın e-posta adresi) alanlarını içerir. await kullanılarak, işlem tamamlanana kadar beklenir.
            user: loggedInUser.email,
            friend: friendEmail
        });

        alert("Arkadaş başarıyla eklendi.");
        friendEmailInput.value = ""; //E-posta adresi giriş kutusunu temizler.
        loadFriendsList(loggedInUser.email); //Kullanıcının güncel arkadaş listesini yükler. loadFriendsList fonksiyonu, arkadaşların veritabanından çekilmesi ve görüntülenmesi için kullanılır.
    } catch (error) {
        console.error("Arkadaş eklenirken hata oluştu:", error);
        alert("Arkadaş eklenemedi. Lütfen tekrar deneyin."); //Eğer herhangi bir hata oluşursa, hata konsola yazdırılır ve kullanıcıya bir hata mesajı gösterilir.
    }
}

// Chat Functions
function markMessagesAsSeen(friendEmail) {
    const q = query( //Bu satırda, Firebase Firestore'dan belirli bir arkadaşla yapılmış mesajları sorgulayan bir sorgu oluşturuluyor. Bu sorgu, messages koleksiyonundan alınacak mesajlar için bir dizi filtre uygular:
        collection(db, "messages"),
        where("recipient", "==", auth.currentUser.email),
        where("sender", "==", friendEmail),
        where("status", "==", "Delivered")
    );

    getDocs(q).then((snapshot) => { //getDocs(q) ile belirtilen sorguya göre veriler Firestore'dan çekilir. Bu, mesajların bir "snapshot" (fotoğraf) versiyonunu alır ve ardından .then() metodu ile işlem devam eder.
        snapshot.forEach(async (doc) => { //snapshot.forEach() ile her bir döküman (mesaj) üzerinde işlem yapılır. Bu işlem her bir mesajı "görüldü" (Seen) olarak işaretlemek için yapılır.Asenkron
            await updateDoc(doc.ref, { status: "Seen" }); //Her bir mesaj dökümanı (doc), updateDoc fonksiyonu ile güncellenir. Bu fonksiyon, status alanını "Seen" olarak değiştirir, böylece bu mesajın görüldüğü işaretlenir.
        });
    });
}

// loadChatWith fonksiyonuna "Seen" durumunu ekleme
function loadChatWith(friendEmail) { //friendEmail, kullanıcının şu anda sohbet ettiği arkadaşın e-posta adresini belirtir ve bu değer currentChatFriend değişkenine atanır. Böylece bu arkadaşla olan sohbetin yüklenmesi sağlanır.
    currentChatFriend = friendEmail;
    const messagesList = document.getElementById("messagesList"); //HTML'deki messagesList ID'sine sahip div öğesini seçer. Bu öğe, sohbetin mesajlarını görüntüleyecek alandır.
    messagesList.innerHTML = ""; //Mesajlar listesinin içeriğini temizler. Bu, yeni mesajlar yüklendiğinde eski mesajların silinmesini sağlar.

    const q = query(
        collection(db, "messages"), //messages koleksiyonundan, mesajların zaman damgasına (timestamp) göre sıralandığı bir sorgu oluşturulur. Bu sorgu, mesajları kronolojik sırayla alır.
        orderBy("timestamp", "asc") //orderBy("timestamp", "asc"): Mesajlar, zaman damgasına göre artan sırayla (ilk gönderilen mesajdan başlayarak) sıralanır.
    );

    onSnapshot(q, (querySnapshot) => { //onSnapshot fonksiyonu, Firestore'daki messages koleksiyonundaki verileri dinler. Yani, veritabanındaki her değişiklik anında (yeni mesaj geldiğinde, bir mesaj okunduğunda vb.) bu fonksiyon tetiklenir.
        messagesList.innerHTML = "";
        querySnapshot.forEach((doc) => { //Firestore'dan alınan her bir mesaj (doc) üzerinde işlem yapılır.
            const data = doc.data();
            if (
                (data.sender === auth.currentUser?.email && data.recipient === currentChatFriend) || //Eğer mesaj, giriş yapan kullanıcı ile currentChatFriend arasında ise (yani, mesaj bu sohbetle ilgiliyse) aşağıdaki işlemler yapılır.
                (data.sender === currentChatFriend && data.recipient === auth.currentUser?.email)
            ) {
                const messageElement = document.createElement("div");
                messageElement.classList.add( //Mesajın gönderildiği veya alındığına göre ilgili sınıf (sent veya received) eklenir. Bu sınıflar, CSS ile farklı stillerle gösterilmesini sağlar.
                    "message",
                    data.sender === auth.currentUser?.email ? "sent" : "received"
                );
                messageElement.innerHTML = `
                    <strong>${data.sender}</strong><br />
                    <span>${data.content}</span><br />
                    <small>Durum: ${data.status || "Gönderiliyor"}</small> 
                `;//Mesajın içeriği, gönderenin adı, mesajın içeriği ve mesajın durumu (gönderilme durumu) HTML içeriği olarak eklenir.
                messagesList.appendChild(messageElement); //Oluşturulan mesaj öğesi, mesajlar listesine eklenir.
            }
        });
        messagesList.scrollTop = messagesList.scrollHeight; //Mesajlar eklendikçe, sohbet penceresinin en altına kaydırılır. Bu, yeni gelen mesajların görünür olmasını sağlar.

        // Mesajları "Seen" olarak işaretle
        if (auth.currentUser.email !== currentChatFriend) { //Eğer mesajları gönderen kullanıcı (yani sohbeti başlatan kişi) şu anda aktif kullanıcı değilse, mesajlar "görüldü" (Seen) olarak işaretlenir. markMessagesAsSeen fonksiyonu çağrılır.
            markMessagesAsSeen(currentChatFriend);
        }
    });
}

// Send Message
async function sendMessage() {
    const messageContent = document.getElementById("messageContent").value.trim();
    if (!messageContent || !currentChatFriend) {
        alert("Lütfen bir kişi seçin ve bir mesaj yazın.");
        return;
    }

    if (!navigator.onLine) {
        // İnternet bağlantısı yok, mesaj gönderilmedi olarak işaretle
        const loggedInUser = auth.currentUser;
        await addDoc(collection(db, "messages"), {
            sender: loggedInUser.email,
            recipient: currentChatFriend,
            content: messageContent,
            timestamp: new Date(),
            status: "Not Sent",
        });

        document.getElementById("messageContent").value = "";
        alert("İnternet bağlantısı yok. Mesaj gönderilemedi.");
        return;
    }

    try {
        const loggedInUser = auth.currentUser;
        await addDoc(collection(db, "messages"), {
            sender: loggedInUser.email,
            recipient: currentChatFriend,
            content: messageContent,
            timestamp: new Date(),
            status: "Sent",
        });

        document.getElementById("messageContent").value = "";
    } catch (error) {
        console.error("Mesaj gönderilirken hata oluştu:", error);
    }
}

// Group Message Modal
function openGroupMessageModal() {
    const modal = document.getElementById('groupMessageModal');
    const recipientList = document.getElementById('recipientList');
    recipientList.innerHTML = "";

    const q = query(collection(db, "friends"), orderBy("friend", "asc"));

    onSnapshot(q, (querySnapshot) => {
        querySnapshot.forEach((doc) => {
            const { user, friend } = doc.data();
            if (user === auth.currentUser?.email) {
                const li = document.createElement("li");
                const checkbox = document.createElement("input");
                checkbox.type = "checkbox";
                checkbox.value = friend;

                const label = document.createElement("label");
                label.textContent = friend;

                li.appendChild(checkbox);
                li.appendChild(label);
                recipientList.appendChild(li);
            }
        });
    });

    modal.style.display = "flex";
}

function closeGroupMessageModal() {
    const modal = document.getElementById('groupMessageModal');
    modal.style.display = "none";
}

async function sendGroupMessage() {
    const recipients = Array.from(document.querySelectorAll('#recipientList input[type="checkbox"]:checked'))
            .map(checkbox => checkbox.value);
            const messageContent = document.getElementById('groupMessageContent').value.trim();
        
            if (recipients.length === 0 || !messageContent) {
                alert("Lütfen bir mesaj yazın ve en az bir kişi seçin.");
                return;
            }
        
            if (!navigator.onLine) {
                // İnternet bağlantısı yok, mesaj gönderilmedi olarak işaretle
                const loggedInUser = auth.currentUser;
                for (const recipient of recipients) {
                    await addDoc(collection(db, "messages"), {
                        sender: loggedInUser.email,
                        recipient,
                        content: messageContent,
                        timestamp: new Date(),
                        status: "Not Sent",
                    });
                }
        
                alert("İnternet bağlantısı yok. Mesaj gönderilemedi.");
                closeGroupMessageModal();
                return;
            }
        
            try {
                const loggedInUser = auth.currentUser;
                for (const recipient of recipients) {
                    await addDoc(collection(db, "messages"), {
                        sender: loggedInUser.email,
                        recipient,
                        content: messageContent,
                        timestamp: new Date(),
                        status: "Sent", // Başlangıçta "Sent" olarak işaretle
                    });
                }
        
                alert("Mesaj gönderildi!");
                closeGroupMessageModal();
            } catch (error) {
                console.error("Error sending group message:", error);
            }
        }
        
        onAuthStateChanged(auth, (user) => {
            if (user) {
                onSnapshot(
                    query(
                        collection(db, "messages"),
                        where("recipient", "==", auth.currentUser.email),
                        where("status", "==", "Sent")
                    ),
                    (snapshot) => {
                        snapshot.forEach(async (doc) => {
                            await updateDoc(doc.ref, { status: "Delivered" });
                        });
                    }
                );
            }
        });
        