// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-auth.js";
import { getFirestore, setDoc, doc } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyDCAkVAn2GYk9JwTe33G9-IbRl2LzwGVjE",
    authDomain: "bartin2-7ad48.firebaseapp.com",
    projectId: "bartin2-7ad48",
    storageBucket: "bartin2-7ad48.appspot.com",
    messagingSenderId: "1088843251815",
    appId: "1:1088843251815:web:baeec13841948a248714c2"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

function showMessage(message, divId) {
    var messageDiv = document.getElementById(divId);
    messageDiv.style.display = "block";
    messageDiv.innerHTML = message;
    messageDiv.style.opacity = 1;
    setTimeout(function () {
        messageDiv.style.opacity = 0;
    }, 5000);
}

// Password validation function
function validatePassword(password) {
    // Nokta karakterini de özel karakterlere ekledik
    const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*.])[A-Za-z\d!@#$%^&*.]{6,12}$/;
    return passwordRegex.test(password);
}
const signUp = document.getElementById('submitSignUp');
signUp.addEventListener('click', (event) => {
    event.preventDefault();
    const email = document.getElementById('email_1').value;
    const password = document.getElementById('password_1').value;
    const confirmPassword = document.getElementById('password_2').value;
    const firstName = document.getElementById('name_1').value;
    const lastName = document.getElementById('surname_1').value;

    // Check if passwords match
    if (password !== confirmPassword) {
        showMessage('Şifreler uyuşmuyor', 'signUpMessage');
        return;
    }

    // Validate password strength
    if (!validatePassword(password)) {
        showMessage('Şifre en az bir büyük harf, bir sayı, bir özel karakter içermeli ve 6-12 karakter uzunluğunda olmalı.', 'signUpMessage');
        return;
    }

    const auth = getAuth();
    const db = getFirestore();

    createUserWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {
            const user = userCredential.user;
            const userData = {
                email: email,
                firstName: firstName,
                lastName: lastName
            };
            showMessage('Hesap Oluşturuldu', 'signUpMessage');
            const docRef = doc(db, "users", user.uid);
            setDoc(docRef, userData)
                .then(() => {
                    window.location.href = "homepage.html";
                })
                .catch((error) => {
                    console.error("Hata", error);
                });
        })
        .catch((error) => {
            const errorCode = error.code;
            if (errorCode == 'auth/email-already-in-use') {
                showMessage('Email Zaten Kullanılıyor', 'signUpMessage');
                window.location.href = 'index.html';
            } else {
                showMessage('Kayıtlı Email', 'signUpMessage');
            }
        });
});

const signIn = document.getElementById('submitSignIn');
signIn.addEventListener('click', (event) => {
    event.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const auth = getAuth();

    signInWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {
            showMessage('Giriş Başarılı', 'signInMessage');
            const user = userCredential.user;
            localStorage.setItem('loggedInUserId', user.uid);
            window.location.href = 'homepage.html';
        })
        .catch((error) => {
            const errorCode = error.code;
            if (errorCode === 'auth/invalid-credential') {
                showMessage('Hatalı Email veya Şifre', 'signInMessage');
            } else {
                showMessage('Hatalı Email veya Şifre', 'signInMessage');
            }
        });
});
