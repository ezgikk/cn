import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-auth.js";
import { getFirestore, addDoc, collection, doc, getDoc } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyDCAkVAn2GYk9JwTe33G9-IbRl2LzwGVjE",
    authDomain: "bartin2-7ad48.firebaseapp.com",
    projectId: "bartin2-7ad48",
    storageBucket: "bartin2-7ad48.appspot.com",
    messagingSenderId: "1088843251815",
    appId: "1:1088843251815:web:baeec13841948a248714c2"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth();
const db = getFirestore();

// Kullanıcı giriş durumunu kontrol et
onAuthStateChanged(auth, (user) => {
    const loggedInUserId = localStorage.getItem('loggedInUserId');
    if (loggedInUserId) {
        const docRef = doc(db, "users", loggedInUserId);
        getDoc(docRef).then((docSnap) => {
            if (docSnap.exists()) {
                const userData = docSnap.data();
                document.getElementById('loggedUsername_1').innerText = userData.firstName;
                document.getElementById('loggedUsersurname_1').innerText = userData.lastName;
                document.getElementById('loggedUseemail_1').innerText = userData.email;
            } else {
                console.log("Kullanıcı bulunamadı.");
            }
        }).catch((error) => {
            console.error("Hata oluştu:", error);
        });
    } else {
        console.log("Kullanıcı oturumu bulunamadı.");
    }
});

// Mesaj gönderme işlevi
const sendMessageButton = document.getElementById('sendMessageButton');
sendMessageButton.addEventListener('click', async () => {
    const recipientEmail = document.getElementById('recipientEmail').value;
    const messageContent = document.getElementById('messageContent').value;

    if (!recipientEmail || !messageContent) {
        alert("Lütfen alıcı e-postasını ve mesajınızı doldurun.");
        return;
    }

    try {
        const loggedInUserId = localStorage.getItem('loggedInUserId');
        const senderDocRef = doc(db, "users", loggedInUserId);
        const senderDocSnap = await getDoc(senderDocRef);

        if (senderDocSnap.exists()) {
            const senderEmail = senderDocSnap.data().email;

            await addDoc(collection(db, "messages"), {
                sender: senderEmail,
                recipient: recipientEmail,
                content: messageContent,
                timestamp: new Date()
            });

            alert("Mesaj başarıyla gönderildi.");
            document.getElementById('recipientEmail').value = "";
            document.getElementById('messageContent').value = "";
        } else {
            alert("Gönderici bilgisi alınamadı.");
        }
    } catch (error) {
        console.error("Mesaj gönderme hatası:", error);
        alert("Mesaj gönderirken bir hata oluştu.");
    }
});

