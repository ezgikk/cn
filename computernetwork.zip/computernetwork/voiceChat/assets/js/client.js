//var connection = new WebSocket('ws://localhost:9090');
//change it to your ip (in the terminal run ipconfig "IPv4 Address" )
var connection = new WebSocket('wss://192.168.1.102:9090');

var name;
var connected_user;
var connectedUser;
var myConn;
var stream;
var dataChannel;
var isCallInProgress = false;

var call_btn = document.querySelector("#call-btn");
var call_to_username_input = document.querySelector("#username-input");
var call_status = document.querySelector(".call-hang-status");
var chatArea = document.querySelector("#chat-area");

var url_string = window.location.href;
var url = new URL(url_string);
var urlParams = new URLSearchParams(window.location.search);
var username = urlParams.get("username");

if (username) {
    name = username;
    send({ type: "login", name: name });
} else {
    alert("No username provided! Redirecting to login page.");
    window.location.replace("login.html");
}

function loginProcess(success) {
    if (!success) {
        alert("Username already in use");
        window.location.replace("login.html");

        return;
    }

    navigator.mediaDevices.getUserMedia({ video: false, audio: true })
        .then(setupWebRTCConnection)
        .catch(handleMediaError);
}


connection.onopen = function () {
    console.log("Connected to the server");
    if (username) {
        name = username;
        send({ type: "login", name: name });
    } else {
        alert("No username provided! Redirecting to login page.");
        window.location.replace("login.html");
    }
}

connection.onmessage = function (msg) {
    var data = JSON.parse(msg.data);
    switch (data.type) {
        case "login":
            loginProcess(data.success);
            break;


        case "offer":
            if (!isCallInProgress) {
                handleIncomingCall(data);
            }
            break;
        case "answer":
            answerProcess(data.answer);
            break;
        case "candidate":
            candidateProcess(data.candidate);
            break;
        case "leave":
            leaveProcess(true);
            break;
        case "rejected":
            handleCallRejection(data.name);
            break;
            case "call_timeout":
                handleCallTimeout(data.message);
            
    }
};

function displayMissedCalls(missedCalls) {
    if (missedCalls && missedCalls.length > 0) {
        const callList = missedCalls.join(", ");
        alert(`You have missed calls from: ${callList}`);
    }
}

connection.onerror = function (error) {
    console.log("WebSocket Error:", error);
}

// Periodically check and reconnect WebSocket if disconnected
setInterval(function() {
    if (connection.readyState === WebSocket.CLOSED) {
        connection = new WebSocket('ws://192.168.1.100:9090');

        if (username != null && username.length > 0) {
            name = username;
            send({ type: "login", name: name });
        }
    }
}, 5000);

// Handle call rejection
function handleCallRejection(caller) {
    isCallInProgress = false;
    alert("reject")

    setTimeout(() => {
        call_status.innerHTML = '';
    }, 3000);
}
function handleCallTimeout(message) {
    alert(message); // Notify the user about the timeout
    leaveProcess(false); // Reset the call state
}


call_btn.addEventListener("click", function () {
    if (isCallInProgress) {
        alert("Another call is in progress");
        return;
    }

    var call_to_username = call_to_username_input.value;
    if (call_to_username.length > 0) {
        connected_user = call_to_username;
        initializeCall(call_to_username);
    }
});

function handleMissedCall(data) {
    // Only display the notification if the current user is the callee
    if (name !== data.caller) {
        const missedCallNotification = document.createElement('div');
        missedCallNotification.classList.add('missed-call-notification');
        missedCallNotification.innerHTML = `
            <div class="missed-call-alert" style="z-index: 1000; position: fixed; top: 10px; right: 10px; background: #fff; padding: 10px; border-radius: 5px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);">
                <div class="missed-call-icon" style="display: flex; align-items: center; gap: 10px;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#FF0000">
                        <path d="M19.59 7L12 14.59 4.41 7 3 8.41 12 17.41 21 8.41z"/>
                    </svg>
                    <span style="color: #000; font-weight: bold;">Missed call from ${data}</span>
                </div>
            </div>
        `;

        // Add the notification to the body
        document.body.appendChild(missedCallNotification);

        // Remove the notification after 10 seconds
        setTimeout(() => {
            document.body.removeChild(missedCallNotification);
        }, 10000);
    }
}


function send(message) {
    if (connection.readyState === WebSocket.OPEN) {
        if (connected_user) {
            message.name = connected_user;
        }
        connection.send(JSON.stringify(message));
    } else {
        console.log("WebSocket is not open. Unable to send message.");
    }
}




function setupWebRTCConnection(myStream) {
    stream = myStream;

    const configuration = {
        iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
    };

    // Initialize RTCPeerConnection
    myConn = new RTCPeerConnection(configuration); // Use `RTCPeerConnection` (modern API)
    
    myConn.addStream(stream);

    myConn.onicecandidate = (event) => {
        if (event.candidate) {
            send({
                type: "candidate",
                candidate: event.candidate,
            });
        }
    };

    myConn.onaddstream = (e) => {
        createAudioElement(e.stream);
    };

    setupDataChannel();
}


function setupDataChannel() {
    // Reset existing data channel
    if (dataChannel) {
        dataChannel.close();
    }

    dataChannel = myConn.createDataChannel("channel1", { reliable: true });
    
    dataChannel.onerror = function (error) {
        console.log("Data Channel Error:", error);
    };
    
    dataChannel.onmessage = function (event) {
        chatArea.innerHTML += `<div class='left-align' style='display:flex;align-items:center;'>
            <div style='font-weight:600;margin:0 5px;'>${connected_user}</div>: 
            <div>${event.data}</div>
        </div><br/>`;
    };
}

function setupConnectionHandlers() {
    myConn.addStream(stream);

    myConn.onaddstream = function (e) {
        createAudioElement(e.stream);
    };

    myConn.onicecandidate = function (event) {
        if (event.candidate) {
            send({
                type: "candidate",
                candidate: event.candidate
            });
        }
    };
}

function handleMediaError(error) {
    console.log("Media Access Error:", error);
}

function initializeCall(targetUsername) {
    if (isCallInProgress) {
        alert("Cannot start a new call. A call is already in progress.");
        return;
    }

    isCallInProgress = true;
    connected_user = targetUsername;

    // Update call status UI
    updateCallStatus(targetUsername);

    myConn.createOffer()
        .then((offer) => {
            myConn.setLocalDescription(offer);
            send({
                type: "offer",
                offer: offer,
            });
        })
        .catch((error) => {
            isCallInProgress = false;
            alert("Offer creation failed");
            console.error("Error creating offer:", error);
        });
}




function handleIncomingCall(data) {
    isCallInProgress = true;
    updateIncomingCallStatus(data.name);

    var call_receive = document.querySelector('.call-accept');
    var call_reject = document.querySelector('.call-reject');

    // Remove any existing event listeners to prevent multiple attachments
    var newCallReceive = call_receive.cloneNode(true);
    var newCallReject = call_reject.cloneNode(true);
    call_receive.parentNode.replaceChild(newCallReceive, call_receive);
    call_reject.parentNode.replaceChild(newCallReject, call_reject);

    newCallReceive.addEventListener("click", function () {
        acceptCall(data.name);
        processOffer(data.offer, data.name);
    });

    newCallReject.addEventListener("click", function () {
        rejectCall(data.name);
    });
}

function processOffer(offer, name) {
    if (!myConn) {
        console.error("RTCPeerConnection not initialized. Cannot set remote description.");
        return;
    }

    connected_user = name;
    myConn.setRemoteDescription(new RTCSessionDescription(offer))
        .then(() => {
            myConn.createAnswer()
                .then((answer) => {
                    myConn.setLocalDescription(answer);
                    send({
                        type: "answer",
                        answer: answer,
                    });
                })
                .catch((error) => {
                    console.error("Error creating answer:", error);
                });
        })
        .catch((error) => {
            console.error("Error setting remote description:", error);
        });
}


function answerProcess(answer) {
    myConn.setRemoteDescription(new RTCSessionDescription(answer));
}

function candidateProcess(candidate) {
    if (myConn) {
        myConn.addIceCandidate(new RTCIceCandidate(candidate))
            .catch((error) => {
                console.error("Error adding ICE candidate:", error);
            });
    } else {
        console.error("RTCPeerConnection not initialized. Cannot process ICE candidate.");
    }
}



function createAudioElement(remoteStream) {
    var audioElement = document.createElement('audio');
    audioElement.srcObject = remoteStream;
    audioElement.play();
    document.body.appendChild(audioElement);

    setupCallControls(remoteStream);
}

function setupCallControls(remoteStream) {
    call_status.innerHTML = `
    <div class="call-container">
        <div class="call-header">
            <div class="user-profile">
                <img src="default-avatar.png" alt="User Avatar" class="user-avatar">
                <div class="user-details">
                    <h2 class="username">${connected_user}</h2>
                    <p class="call-duration">00:00</p>
                </div>
            </div>
        </div>
        <div class="call-controls">
            <div class="control-group">
                <button class="control-btn audio-on">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="white">
                        <path d="M12 14c1.66 0 2.99-1.34 2.99-3L15 5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z"/>
                    </svg>
                </button>
                <span class="control-label">Mute</span>
            </div>
            <div class="control-group">
                <button class="control-btn call-cancel end-call">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="white">
                        <path d="M12 9c-1.6 0-3.15.25-4.6.72v3.1c0 .39-.23.74-.56.9-.98.48-1.87 1.12-2.66 1.85-.18.18-.43.28-.7.28H.71c-.39 0-.71-.32-.71-.71 0-.18.07-.35.18-.48C2.34 11.14 5.05 10 8 10c.55 0 1 .45 1 1v2.5c0 .28.22.5.5.5h1c.28 0 .5-.22.5-.5V11c0-1.1.9-2 2-2h8V8c0-1.1-.9-2-2-2H6.71l1.59-1.59L6.71 3 2 7.71v8.78h16v-4l-4-4h-2.5v2c0 1.38-1.12 2.5-2.5 2.5H8v-2l-4-4v10h16v-2H6v-2h12v-2H6z"/>
                    </svg>
                </button>
                <span class="control-label">End Call</span>
            </div>
        </div>
    </div>
`;

    setupAudioToggle(remoteStream);
    setupCallTermination();
    startCallDurationTimer();
}

function startCallDurationTimer() {
    const durationEl = document.querySelector('.call-duration');
    let seconds = 0;
    const timer = setInterval(() => {
        seconds++;
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        durationEl.textContent = `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
    }, 1000);

    // Stop timer when call ends
    const callCancelBtn = document.querySelector('.end-call');
    
    callCancelBtn.addEventListener('click', () => clearInterval(timer));
}

function setupAudioToggle(remoteStream) {
    var audio_toggle = document.querySelector('.audio-on');
    audio_toggle.onclick = function () {
        stream.getAudioTracks()[0].enabled = !stream.getAudioTracks()[0].enabled;
        
        var audio_toggle_class = document.querySelector('.audio-toggle');
        audio_toggle_class.innerText = audio_toggle_class.innerText === 'mic' ? 'mic_off' : 'mic';
    };
}

function setupCallTermination() {
    var call_cancel = document.querySelector('.call-cancel');
    call_cancel.addEventListener("click", function () {
        send({ type: "leave", name: connected_user });
        leaveProcess(false);
    });
}

function updateCallStatus(username) {
    call_status.innerHTML = `
        <div class="calling-status-wrap">
            <div class="user-info">
                <div class="user-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="#3B82F6">
                        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                    </svg>
                </div>
                <div class="username">${username}</div>
            </div>
            <div class="user-calling-status">Calling...</div>
            <div class="calling-action">
                <div class="call-reject">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="white">
                        <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                </div>
            </div>
        </div>
    `;

    // Attach event listener to the cancel button
    const cancelBtn = document.querySelector(".call-reject");
    cancelBtn.addEventListener("click", function () {
        // Send a missed call notification before leaving
        send({ type: "missed_call", name: name });
        send({ type: "leave", name: username });
        leaveProcess(false);
    });
}


function updateIncomingCallStatus(username) {
    call_status.innerHTML = `
        <div class="calling-status-wrap">
            <div class="user-info">
                <div class="user-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="#10B981">
                        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                    </svg>
                </div>
                <div class="username">${username}</div>
            </div>
            <div class="user-calling-status">Incoming Call...</div>
            <div class="calling-action">
                <div class="call-accept">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="white">
                        <path d="M20.1 7.7l-1 1c1.8 1.8 1.8 4.6 0 6.5l1 1c2.5-2.3 2.5-6.1 0-8.5zM18 9.8l-1 1c.5.7.5 1.6 0 2.3l1 1c1.2-1.2 1.2-3 0-4.3zM14 1H4c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-2-2-2zm0 19H4V3h10v17z"/>
                    </svg>
                </div>
                <div class="call-reject">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="white">
                        <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                    </svg>
                </div>
            </div>
        </div>
    `;
}

function leaveProcess(wasRemoteInitiated = false) {
    isCallInProgress = false;


    if (!wasRemoteInitiated && connected_user) {
        send({
            type: "missed_call",
            caller: name,
            callee: connected_user,
        });
    }

    // Remove audio element
    var audioElement = document.querySelector('audio');
    if (audioElement) {
        audioElement.remove();
    }

    // Close WebRTC connection
    if (myConn) {
        myConn.close();
        myConn = null;
    }

    // Stop media stream
    if (stream) {
        stream.getTracks().forEach(track => track.stop());
        stream = null;
    }

    connected_user = null;
    call_status.innerHTML = '';

    // Reinitialize WebRTC 
    loginProcess(true);
}

function acceptCall(callee_name) {
    send({ type: "accept", name: callee_name });
}

function rejectCall(caller_name) {
    isCallInProgress = false;
    send({ type: "rejected", name: caller_name });
    send({ type: "leave", name: caller_name });
    call_status.innerHTML = '';
    leaveProcess(false);
}