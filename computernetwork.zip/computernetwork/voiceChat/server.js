const https = require('https');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');
const express = require('express');

// Load SSL certificate and private key
const serverOptions = {
    key: fs.readFileSync('server.key'), // Path to your private key
    cert: fs.readFileSync('server.cert') // Path to your certificate
};

// Initialize Express to serve static files
const app = express();
app.use(express.static(path.join(__dirname, '/'))); // Serves files from the current directory

// Create HTTPS server
const httpsServer = https.createServer(serverOptions, app);

// Create WebSocket server on top of HTTPS server
const wss = new WebSocket.Server({ server: httpsServer });

// Store connected users and missed calls
const users = {};
const missedCalls = {}; // Tracks missed calls for each user


// WebSocket connection handler
wss.on('connection', (conn) => {
    console.log("A user connected");

    conn.on('message', (message) => {
        let data;
        try {
            data = JSON.parse(message);
        } catch (error) {
            console.log("Invalid JSON received:", message);
            sendTo(conn, { type: "error", message: "Invalid JSON format" });
            return;
        }

        // Handle different message types
        switch (data.type) {
            case "login":
                handleLogin(conn, data);
                break;
            case "offer":
                handleOffer(conn, data);
                break;

            case "answer":
                handleAnswer(conn, data);
                break;
            case "candidate":
                handleCandidate(conn, data);
                break;
            case "leave":
                handleLeave(conn, data);
                break;
            case "rejected":
                handleReject(conn, data);
                break;
            default:
                sendTo(conn, { type: "error", message: "Unknown command: " + data.type });
        }
    });

    conn.on('close', () => {
        handleDisconnect(conn);
    });

    conn.on('error', (error) => {
        console.log("WebSocket error:", error.message);
    });

    // Send welcome message
    sendTo(conn, { type: "welcome", message: "Connected to WebSocket server" });
});

// Handle user login
function handleLogin(conn, data) {
    if (users[data.name]) {
        sendTo(conn, { type: "login", success: false, message: "Username already in use" });
    } else {
        users[data.name] = conn;
        conn.name = data.name;

        // Send missed call notifications
        if (missedCalls[data.name] && missedCalls[data.name].length > 0) {
            sendTo(conn, {
                type: "missed_call_list",
                missedCalls: missedCalls[data.name],
            });
            delete missedCalls[data.name]; // Clear missed calls after notifying the user
        }

        sendTo(conn, { type: "login", success: true });
        console.log(`User logged in: ${data.name}`);
    }
}

// Handle WebRTC offer
function handleOffer(conn, data) {
    const target = users[data.name];
    if (target) {
        conn.otherUser = data.name;
        sendTo(target, {
            type: "offer",
            offer: data.offer,
            name: conn.name
        });

        // Set a timeout for unanswered calls
        setTimeout(() => {
            if (conn.otherUser === data.name && users[data.name]?.otherUser === conn.name) {
                // Notify both users about the timeout
                sendTo(conn, { type: "call_timeout", message: "Call timed out due to no response." });
                sendTo(target, { type: "call_timeout", message: "Call timed out due to no response." });

                // Cleanup connections
                handleLeave(conn, { name: data.name });
                handleLeave(target, { name: conn.name });
            }
        }, 10000); // 10 seconds timeout
    } else {
        sendTo(conn, { type: "error", message: "Target user not found" });
    }
}


// Handle WebRTC answer
function handleAnswer(conn, data) {
    const target = users[data.name];
    if (target) {
        sendTo(target, {
            type: "answer",
            answer: data.answer
        });
    } else {
        sendTo(conn, { type: "error", message: "Target user not found" });
    }
}

// Handle ICE candidate
function handleCandidate(conn, data) {
    const target = users[data.name];
    if (target) {
        sendTo(target, {
            type: "candidate",
            candidate: data.candidate
        });
    } else {
        sendTo(conn, { type: "error", message: "Target user not found" });
    }
}

// Handle missed call logging
function handleMissedCall(conn, data) {
    const { caller, callee } = data;

    if (!caller || !callee) {
        return;
    }

    // Log missed call for the callee
    if (!missedCalls[callee]) {
        missedCalls[callee] = [];
    }
    missedCalls[callee].push(caller);

    console.log(`Missed call logged: ${caller} -> ${callee}`);

    // Notify the caller that the callee is unavailable
    sendTo(conn, {
        type: "missed_call_ack",
        message: `${callee} is not available. Missed call logged.`,
    });
}


// Handle user rejection of call
function handleReject(conn, data) {
    const target = users[data.name];
    if (target) {
        sendTo(target, {
            type: "rejected",
            name: conn.name,
            message: "Call rejected"
        });
    }
}

// Handle user leaving
function handleLeave(conn, data) {
    const target = users[data.name];
    if (target) {
        sendTo(target, { type: "leave", name: conn.name });
    }
    if (conn.otherUser) {
        delete conn.otherUser;
    }
}

// Handle user disconnection
function handleDisconnect(conn) {
    if (conn.name) {
        console.log(`User disconnected: ${conn.name}`);
        delete users[conn.name];

        if (conn.otherUser) {
            const target = users[conn.otherUser];
            if (target) {
                sendTo(target, { type: "leave", name: conn.name });
            }
        }
    }
}

// Send JSON message to a connection
function sendTo(connection, message) {
    try {
        connection.send(JSON.stringify(message));
    } catch (error) {
        console.log("Failed to send message:", error.message);
    }
}

// Start HTTPS server
httpsServer.listen(9090, () => {
    console.log("HTTPS server running at https://< Your ip >:9090");
});

